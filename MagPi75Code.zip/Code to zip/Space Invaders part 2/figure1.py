def draw()
    # additional drawing code
    drawLives()
    if player.status >= 30:
        if player.lives > 0:
            drawCentreText("YOU WERE HIT!\nPress Enter to re-spawn")
        else:
            drawCentreText("GAME OVER!\nPress Enter to continue")

def init():
    # additional player variables
    player.lives = 3
    player.name = ""

def drawLives():
    for l in range(player.lives): screen.blit("life", (10+(l*32),10))

def update():
    # additional code for life handling
    global player, lasers
    if player.status < 30 and len(aliens) > 0:
        if player.status > 0:
            player.status += 1
            if player.status == 30:
                player.lives -= 1
    else:
        if keyboard.RETURN:
            if player.lives > 0:
                player.status = 0
                lasers = []
            else:
                # go to the leader-board
                pass;

def drawCentreText(t):
    screen.draw.text(t , center=(400, 300), owidth=0.5, ocolor=(255,255,255), color=(255,64,0) , fontsize=60)
